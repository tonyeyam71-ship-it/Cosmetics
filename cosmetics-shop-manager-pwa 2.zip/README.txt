COSMETICS SHOP MANAGER — iPhone PWA prototype

CONTENTS
- index.html: working app
- manifest.webmanifest: install metadata
- sw.js: offline app-shell caching
- icon-192.png, icon-512.png: app icons

WHAT IT DOES
- Product catalogue and stock levels
- Sales and automatic stock deduction
- Expenses and profit estimate
- JSON backup/import and CSV exports
- IndexedDB storage in the browser
- Service worker caches the app shell for offline reopening after first online load

IMPORTANT LIMITATIONS
- This is a single-device app. It has no cloud sync, user authentication, multi-device sync, receipt printing, or tested recovery guarantees.
- Data remains in the browser on this device. Clear browser/site data or device loss can erase it. Export backups often.
- Offline installation requires HTTPS hosting (localhost also works for development). Opening index.html as a file will not enable service worker offline support.
- The app is a progressive web app, not a native App Store binary.

DEPLOY FREE WITH GITHUB PAGES
1. Sign in to GitHub and create a new public repository, e.g. cosmetics-shop-manager.
2. Upload all six files in this folder to the repository root.
3. In repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
4. Wait for GitHub Pages to show the published HTTPS URL.
5. On your iPhone, open that URL in Safari while online. Wait for it to load fully once.
6. Tap Share > Add to Home Screen > Add.
7. Open it from the new home-screen icon. Test airplane mode, add a sample sale, reconnect, and export a backup.
8. This only syncs the app files; it does NOT sync your records to a cloud database.

For true cloud sync, add a backend such as Supabase/Firebase, authentication, row-level security, conflict handling, and a queued offline write/sync layer. Test this before using as your only business record.
